package it.unifi.swa.domain;

public class ModelFactory {
	
	public static Client generateClient(){
		
		Client client=new Client();
		return client;
	}

}
